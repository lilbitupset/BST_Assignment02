package assignment_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Katelynn Urgitus and Taylor Smith
 */
public class BinarySearchTree<K extends Comparable<K>> {

    //root of BST
    private BinarySearchTreeNode<K> root;
    int count = 0;
    int numComparison;
    int comparisonCost;
    int totalHeight;
    int numBelowCounter;

    //main constructor
    BinarySearchTree() {
        root = null;

    }

    // method to recursively insert a new node into the tree
    public void insert(K key) {//throws DuplicatesException {
        root = insert(root, key);
    }

    //inserts a new item into the tree
    private BinarySearchTreeNode<K> insert(BinarySearchTreeNode<K> n, K key) {//throws DuplicatesException {

        //if your tree is empty then return a new node
        if (n == null) {
            return new BinarySearchTreeNode<K>(key, null, null);
        }

        //if the tree is not empty, move down the tree
        // if (n.getKey().equals(key)) {
        //    throw new DuplicatesException("No Duplicates Allowed");
        // }
        //adding key to the  left subtree
        if (key.compareTo(n.getData()) < 0) {
            n.setLeft(insert(n.getLeft(), key));
            return n;
        } //adding key to the right subtree
        else {
            n.setRight(insert(n.getRight(), key));
            return n;
        }
    }

    public boolean search(K key) {
        return search(root, key);
    }

    // method to search the tree for a given key
    private boolean search(BinarySearchTreeNode<K> n, K key) {

        //base cases
        if (n == null) {
            count++;
            return false;
        }

        // when the value in the tree is equal to the key
        if (n.getData().equals(key)) {
            count++;
            return true;
        }

        // when the value in the key is less than the value in the tree
        if (key.compareTo(n.getData()) < 0) {
            count++;
            return search(n.getLeft(), key);
        } //when the value in the key is greater then the value in the tree
        else {
            count++;
            return search(n.getRight(), key);
        }

    }

    //a method to call the delete method
    public void delete(K key) {

        root = delete(root, key);

    }

    // a method to recursively delete the given key for a node
    private BinarySearchTreeNode<K> delete(BinarySearchTreeNode<K> n, K key) {
        if (n == null) {
            return null;
        }
        //if tree is not empty, move down the tree
        //if the key equals the node to be deleted, delete it
        if (key.equals(n.getData())) {

            if (n.getLeft() == null && n.getRight() == null) {
                return null;
            }
            if (n.getLeft() == null) {
                return n.getRight();
            }
            if (n.getRight() == null) {
                return n.getLeft();
            }
            K minValue = (K) minimum(n.getRight());
            n.setData(minValue);
            n.setRight(delete(n.getRight(), minValue));
            return n;
        } else if (key.compareTo(n.getData()) < 0) {

            n.setLeft(delete(n.getLeft(), key));
            return n;
        } else {
            n.setRight(delete(n.getRight(), key));
            return n;
        }
    }

    //finding the minimum value among the nodes
    private K minimum(BinarySearchTreeNode<K> n) {

        if (n.getLeft() == null) {
            return n.getData();
        } else {
            return (K) minimum(n.getLeft());
        }
    }

    //returns the number of tree entries entries that are smaller than the given value
    int numBelow(K key) {
        return numBelow(root, key);
        
    }
    int numBelow(BinarySearchTreeNode<K> n, K key) {
        if (n == null) {
            return 0;
        }
        if(key.equals(n.getData())) {
            return numBelow(n.getLeft(), key);
        }
         if (key.compareTo(n.getData()) < 0) {
            numBelowCounter++;
            return numBelow(n.getLeft(), key);
        }
        return numBelowCounter;
    }

    //returns the number of tree entries that are bigger than the given value
    int numAbove(int key) {

        if (root == null) {
            return 0;
        }
        return 0;
    }

    //returns the number of comparisons made before a successful or unsuccessful search of the value
    int numOfComp(int key) {

        if (root == null) {
            return 0;
        }
        return count;
    }

    //call height method
    public int height() {
        return height(root);
    }

    // find the height  of the tree
    private int height(BinarySearchTreeNode<K> root) {

        //if the tree is empty return zero
        if (root == null) {
            return 0;
        } else {
            // compute the height of each subtree
            int lHeight = height(root.getLeft());
            int rHeight = height(root.getRight());

            if (lHeight > rHeight) {
                return (lHeight + 1);
            } else {
                return (rHeight + 1);
            }
        }
    }

    public int bstSize() {
        return bstSize(root);
    }

    // find the size of the tree
    private int bstSize(BinarySearchTreeNode<K> root) {

        if (root == null) {
            return 0;
        } else {
            return (bstSize(root.getLeft()) + 1 + bstSize(root.getRight()));
        }
    }

    //calls the recursive inorder display
    void inorder() {
        inorderRec(root);
    }

    //method to do an inorder traversal of the BST
    void inorderRec(BinarySearchTreeNode root) {

        if (root != null) {
            inorderRec(root.getLeft());
            System.out.println(root.getData());
            inorderRec(root.getRight());
        }
    }

    //method to take in number of values to be stored in a number of trees to generate
    public static List<Object> returnAverageComparisons() {

        Scanner input = new Scanner(System.in);

        System.out.println("Please enter the number of items to be stored.");
        int values = input.nextInt();

        System.out.println("Please enter the number of trees to generate");
        int trees = input.nextInt();

        String avgCostStr = "The average cost for these values is : ";
        double avgCost = 0;

        String avgHeightStr = "The average height for these values is : ";
        double avgHeight = 0;

        if (values == 0 || trees == 0) {
            return Arrays.asList(avgCostStr, 0, avgHeightStr, 0);
        }

        int counter = trees;
        ArrayList<BinarySearchTree> treeList = new ArrayList<BinarySearchTree>();

        while (counter > 0) {

            //generate a tree
            BinarySearchTree generatedTree = new BinarySearchTree();
            //pick an arbitrary number of values to store in that tree
            int numberOfNodes = (int) (Math.random() * values + 1);
            int denominator = numberOfNodes;
            //create random values to store in the tree
            while (numberOfNodes > 0) {
                int arbitraryNum = (int) (Math.random() * 1_000_000 + 1);
                if (generatedTree.search(arbitraryNum)) {
                    System.out.println("dup found " + arbitraryNum);
                    continue;
                }
                generatedTree.insert(arbitraryNum);
                //calculate the number of comparisons for the whole bst
                generatedTree.setNumComparison(generatedTree.numOfComp(arbitraryNum));
                numberOfNodes--;
            }

            treeList.add(generatedTree);
            generatedTree.setComparisonCost(generatedTree.getNumComparison() / denominator);
            counter--;
        }
        ///array list containing heights of each tree
        int sumHeights = 0;
        for (int i = 0; i < treeList.size(); i++) {
            sumHeights += (treeList.get(i).height());
        }
        //divide the sum of all the heights of each tree by the number of trees
        avgHeight = sumHeights / trees;
        double sumComparison = 0;
        for (int i = 0; i < treeList.size(); i++) {
            sumComparison += treeList.get(i).getComparisonCost();
        }
        avgCost = sumComparison / trees;

        return Arrays.asList(avgCostStr, avgCost, avgHeightStr, avgHeight);
    }

    public int getNumComparison() {
        return numComparison;
    }

    public void setNumComparison(int numComparison) {
        this.numComparison = numComparison;
    }

    public int getComparisonCost() {
        return comparisonCost;
    }

    public void setComparisonCost(int comparisonCost) {
        this.comparisonCost = comparisonCost;
    }

    public int getTotalHeight() {
        return totalHeight;
    }

    public void setTotalHeight(int totalHeight) {
        this.totalHeight = totalHeight;
    }

}
