// This class is used to contain the left and right child of the current node and key value
package assignment_02;

/**
 *
 * @author Katelynn Urgitus and Taylor Smith
 * @param <K>
 */
public class BinarySearchTreeNode<K> {

    private K data;

    private BinarySearchTreeNode<K> left, right;

    // this method is creating a node and setting the key value input and the right and left children to null
    public BinarySearchTreeNode(K key, BinarySearchTreeNode left, BinarySearchTreeNode right) {
        this.data = key;
        this.left = left;
        this.right = right;
    }

    public K getData() {
        return data;
    }

    public BinarySearchTreeNode getLeft() {
        return left;
    }

    public BinarySearchTreeNode getRight() {
        return right;
    }

    public void setData(K newData) {
        this.data = newData;
    }

    public void setLeft(BinarySearchTreeNode newLeft) {
        this.left = newLeft;
    }

    public void setRight(BinarySearchTreeNode newRight) {
        this.right = newRight;
    }

}
