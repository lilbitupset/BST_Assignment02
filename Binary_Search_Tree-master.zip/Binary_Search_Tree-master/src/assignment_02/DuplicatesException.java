package assignment_02;

/**
 *
 * @author Katelynn Urgitus and Taylor Smith
 */
public class DuplicatesException extends Exception {

    public DuplicatesException(String message) {
        super(message);
    }

}
